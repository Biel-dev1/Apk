# Access App - Flutter

App bonito de Acessibilidade em Flutter para Android

## 🚀 Compilação Rápida

```bash
flutter pub get
flutter build apk --release
```

APK em: build/app/outputs/apk/release/app-release.apk

## ⚙️ Configuração do Servidor

Edite `android/app/src/main/kotlin/com/accessapp/flutter/MainActivity.kt`

Mude: `SERVER_HOST = "192.168.1.100"`
Para: `SERVER_HOST = "SEU_IP"`

Depois recompile.

## 🖥️ Servidor Python

```python
import socket
with socket.socket() as s:
    s.bind(('0.0.0.0', 5000))
    s.listen(5)
    print("Servidor...")
    while True:
        conn, addr = s.accept()
        print(conn.recv(1024).decode())
```

## 📱 Instalar

1. `flutter install`
2. Abra o app
3. Clique "Ativar Acessibilidade"
4. Vá para Configurações > Acessibilidade > Access App > Ativar

## ✨ Pronto para compilar!
